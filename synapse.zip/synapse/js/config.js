/* ===========================================================
   config.js — where the backend lives. Change this if you run
   the server on a different host/port.
   =========================================================== */
const PROXY_URL = "http://localhost:3000";
