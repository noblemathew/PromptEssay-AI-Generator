/* ===========================================================
   session.js — call requireSession() at the top of any page
   that needs the user to be logged in. Confirms the session
   cookie is valid by asking the backend, and returns the
   logged-in user's info (email, name, role).
   =========================================================== */

async function requireSession() {
  try {
    const res = await fetch(PROXY_URL + "/api/me", { credentials: "include" });
    if (!res.ok) throw new Error("not logged in");
    return await res.json();
  } catch (err) {
    window.location.href = "index.html";
    return null;
  }
}

async function logout(redirectTo = "index.html") {
  try {
    await fetch(PROXY_URL + "/auth/logout", { method: "POST", credentials: "include" });
  } finally {
    window.location.href = redirectTo;
  }
}

function initials(name) {
  if (!name) return "?";
  return name.split(" ").map(p => p[0]).slice(0, 2).join("").toUpperCase();
}
