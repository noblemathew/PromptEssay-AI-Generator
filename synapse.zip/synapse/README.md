# Synapse

A multi-tool internal AI platform: one Microsoft sign-in, team-scoped
projects, and a growing set of AI tools launched from within each project.

## What's in here

```
synapse/
├── index.html            Login page ("Sign in with Microsoft")
├── dashboard.html          Your projects + your team (managers only)
├── project.html           AI tools enabled for one project
├── tools/
│   ├── webscraper/         Location Discovery tool (fully working)
│   │   ├── home.html, results.html, workflow.html, agent.html
│   └── coming-soon.html    Placeholder for tools not built yet
├── css/style.css
├── js/
│   ├── config.js            Backend URL
│   └── session.js           Session check + logout, used by every page
└── server/
    ├── server.js            Main Express app — all routes
    ├── auth.js              Microsoft sign-in (+ dev-mode fallback)
    ├── db.js                MySQL connection
    ├── schema.sql            Tables + demo seed data
    ├── package.json
    └── .env.example
```

## 1. Set up MySQL

```sql
CREATE DATABASE synapse;
CREATE USER 'synapse_app'@'localhost' IDENTIFIED BY 'your-password-here';
GRANT ALL PRIVILEGES ON synapse.* TO 'synapse_app'@'localhost';
```

Then load the schema and demo data:
```
mysql -u synapse_app -p synapse < server/schema.sql
```

Edit `server/schema.sql` first if you want different seed data — by
default it creates one manager (`andrew@iqvia.com`), two employees under
him, 4 demo projects, and 4 demo AI tools (only "Location Discovery" is
actually wired up — the other 3 show a "coming soon" page).

## 2. Configure the backend

```
cd server
npm install
cp .env.example .env
```

Fill in `.env`:
- `DB_PASSWORD` — the MySQL password you set above.
- `SESSION_SECRET` — any long random string.
- `POWER_AUTOMATE_URL` / `TOKEN_RESOURCE` — only needed for the
  Location Discovery tool (same as before).
- Leave `ENTRA_CLIENT_ID` / `ENTRA_TENANT_ID` / `ENTRA_CLIENT_SECRET`
  **blank for now** — see below.

## 3. Run it

```
npm start
```

Open **http://localhost:3000** — the backend now serves the frontend
directly, so you don't need a separate static server.

## About sign-in — dev mode vs. real Microsoft sign-in

Right now, without an Entra ID app registration, the app runs in
**dev mode**: the login page shows a "Continue as [name]" button for
each manager/employee seeded in the database, so you can click through
the entire app — dashboard, projects, team management, the Location
Discovery tool — without needing Microsoft sign-in working yet.

**Once IT gives you an Entra ID app registration** (single-tenant, with
redirect URI `http://localhost:3000/auth/callback`), fill in:
```
ENTRA_CLIENT_ID=...
ENTRA_TENANT_ID=...
ENTRA_CLIENT_SECRET=...
```
in `.env` and restart the server. The dev-mode buttons disappear
automatically, and "Sign in with Microsoft" starts doing the real
thing — no code changes needed anywhere.

**Important:** whoever signs in this way must already exist in the
`managers` or `employees` table with a matching email, or they'll see
"your account isn't set up yet." Add people via the dashboard's
"Add team member" (for employees) or directly in the database (for
new managers) — see the note below.

## Adding a new manager

There's no UI for this yet — a manager is the top of the hierarchy, so
the first one(s) are seeded directly in the database:
```sql
INSERT INTO managers (email, display_name) VALUES ('newmanager@iqvia.com', 'Their Name');
```
Once they sign in, they'll see an empty dashboard and can start adding
their own team members and projects through the UI.

## Adding more AI tools later

1. Add a row to the `tools` table (slug, name, description).
2. Enable it for whichever projects should have it, in `project_tools`.
3. Build the tool's pages under `tools/<slug>/`, matching the pattern
   in `tools/webscraper/` — include `js/session.js` for the login guard
   and read `?project=` from the URL if the tool's data should be
   scoped per-project.
4. In `project.html`'s `TOOL_ICONS` object, add an icon for the new
   slug (otherwise it falls back to a wrench icon) — and in the
   click handler, add a case that navigates to the new tool's folder
   instead of falling into "coming soon."

## Security note on the current build

This is a working prototype-grade implementation — good enough to
demo and iterate on, with a few things worth tightening before a wider
rollout:
- Sessions are signed JWTs in an httpOnly cookie — solid for internal
  use, but set `secure: true` in `auth.js` once this is served over
  HTTPS.
- The dev-mode sign-in is intentionally insecure (anyone can "sign in
  as" any seeded user) — it exists only to unblock development before
  real Entra ID sign-in is configured, and disables itself automatically
  the moment real auth is set up.
