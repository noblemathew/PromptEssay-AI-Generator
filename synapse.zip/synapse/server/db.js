/* ===========================================================
   db.js — MySQL connection pool. Every route imports this to
   run queries. Uses mysql2's promise API throughout.
   =========================================================== */

import mysql from "mysql2/promise";
import "dotenv/config";

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || "synapse",
  waitForConnections: true,
  connectionLimit: 10
});

export default pool;
