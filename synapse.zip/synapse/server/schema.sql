-- ===========================================================
-- Synapse — MySQL schema
-- Run this against your `synapse` database after creating it:
--   CREATE DATABASE synapse;
--   USE synapse;
--   SOURCE schema.sql;
-- ===========================================================

CREATE TABLE managers (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  email        VARCHAR(255) UNIQUE NOT NULL,
  display_name VARCHAR(255)
);

CREATE TABLE employees (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  email        VARCHAR(255) UNIQUE NOT NULL,
  display_name VARCHAR(255),
  m_id         INT,
  FOREIGN KEY (m_id) REFERENCES managers(id)
);

CREATE TABLE projects (
  id     INT AUTO_INCREMENT PRIMARY KEY,
  name   VARCHAR(255) NOT NULL,
  m_id   INT,
  FOREIGN KEY (m_id) REFERENCES managers(id)
);

CREATE TABLE tools (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  slug        VARCHAR(100) UNIQUE NOT NULL,
  name        VARCHAR(255) NOT NULL,
  description VARCHAR(500)
);

CREATE TABLE project_tools (
  project_id INT,
  tool_id    INT,
  PRIMARY KEY (project_id, tool_id),
  FOREIGN KEY (project_id) REFERENCES projects(id),
  FOREIGN KEY (tool_id) REFERENCES tools(id)
);

-- ---------------- Seed data (edit freely) ----------------

INSERT INTO managers (email, display_name) VALUES
  ('andrew@iqvia.com', 'Andrew');

INSERT INTO employees (email, display_name, m_id) VALUES
  ('teammate1@iqvia.com', 'Priya Nair', 1),
  ('teammate2@iqvia.com', 'Daniel Osei', 1);

INSERT INTO tools (slug, name, description) VALUES
  ('webscraper',      'Location Discovery',      'Extracts business locations from a company website'),
  ('task-planner',    'Task Assignment Agent',   'Plans, prioritizes and assigns tasks by team member skill'),
  ('doc-summarizer',  'Document Summarizer',     'Summarizes long documents into key points'),
  ('meeting-notes',   'Meeting Notes Analyzer',  'Extracts action items and decisions from meeting transcripts');

INSERT INTO projects (name, m_id) VALUES
  ('Navista Location Mapping',    1),
  ('Q3 Task Planning',            1),
  ('Client Onboarding Analysis',  1),
  ('Regional Outreach Review',    1);

-- Which tools are enabled on which demo project
INSERT INTO project_tools (project_id, tool_id) VALUES
  (1, 1), (1, 2), (1, 3), (1, 4),   -- Navista Location Mapping: all 4
  (2, 2), (2, 3),                    -- Q3 Task Planning
  (3, 1), (3, 4),                    -- Client Onboarding Analysis
  (4, 2), (4, 3), (4, 4);            -- Regional Outreach Review
