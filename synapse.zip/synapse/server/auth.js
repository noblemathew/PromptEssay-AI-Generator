/* ===========================================================
   auth.js — handles both real Microsoft sign-in and a dev-mode
   fallback.

   Real mode kicks in automatically once these are set in .env:
     ENTRA_CLIENT_ID, ENTRA_TENANT_ID, ENTRA_CLIENT_SECRET,
     ENTRA_REDIRECT_URI

   Until then, the app runs in "dev mode" — the login page shows
   stand-in buttons for each seeded manager/employee, so the rest
   of the app is fully clickable while IT provisions the real
   Entra ID app registration. No code changes needed to switch
   over later — just fill in the .env values and restart.
   =========================================================== */

import "dotenv/config";
import jwt from "jsonwebtoken";
import pool from "./db.js";

const SESSION_SECRET = process.env.SESSION_SECRET || "dev-secret-change-me";
const SESSION_COOKIE = "synapse_session";

export const isRealAuthConfigured = Boolean(
  process.env.ENTRA_CLIENT_ID && process.env.ENTRA_TENANT_ID && process.env.ENTRA_CLIENT_SECRET
);

let msalClient = null;
if (isRealAuthConfigured) {
  const { ConfidentialClientApplication } = await import("@azure/msal-node");
  msalClient = new ConfidentialClientApplication({
    auth: {
      clientId: process.env.ENTRA_CLIENT_ID,
      authority: `https://login.microsoftonline.com/${process.env.ENTRA_TENANT_ID}`,
      clientSecret: process.env.ENTRA_CLIENT_SECRET
    }
  });
} else {
  console.warn(
    "\n[dev mode] Entra ID is not configured — using stand-in sign-in for testing.\n" +
    "Set ENTRA_CLIENT_ID, ENTRA_TENANT_ID, ENTRA_CLIENT_SECRET and ENTRA_REDIRECT_URI\n" +
    "in server/.env to switch to real Microsoft sign-in.\n"
  );
}

const REDIRECT_URI = process.env.ENTRA_REDIRECT_URI || "http://localhost:3000/auth/callback";

/** Looks up whether an email belongs to a manager or an employee, and returns their role + record. */
async function resolveIdentity(email) {
  const [managers] = await pool.query("SELECT * FROM managers WHERE email = ?", [email]);
  if (managers.length > 0) {
    return { role: "manager", id: managers[0].id, email, display_name: managers[0].display_name };
  }
  const [employees] = await pool.query("SELECT * FROM employees WHERE email = ?", [email]);
  if (employees.length > 0) {
    return { role: "employee", id: employees[0].id, m_id: employees[0].m_id, email, display_name: employees[0].display_name };
  }
  return null;
}

function issueSession(res, identity) {
  const token = jwt.sign(identity, SESSION_SECRET, { expiresIn: "8h" });
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: false, // set true once served over HTTPS
    maxAge: 8 * 60 * 60 * 1000
  });
}

export function requireSession(req, res, next) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return res.status(401).json({ error: "Not signed in" });
  try {
    req.user = jwt.verify(token, SESSION_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Session expired — please sign in again" });
  }
}

export function registerAuthRoutes(app) {
  app.get("/auth/mode", async (req, res) => {
    if (isRealAuthConfigured) return res.json({ mode: "real" });

    const [managers] = await pool.query("SELECT email, display_name FROM managers");
    const [employees] = await pool.query("SELECT email, display_name FROM employees");
    res.json({
      mode: "dev",
      devUsers: [
        ...managers.map(m => ({ ...m, role: "manager" })),
        ...employees.map(e => ({ ...e, role: "employee" }))
      ]
    });
  });

  // --- Real Microsoft sign-in ---
  app.get("/auth/login", async (req, res) => {
    if (!isRealAuthConfigured) return res.redirect("/index.html");
    const authUrl = await msalClient.getAuthCodeUrl({
      scopes: ["User.Read"],
      redirectUri: REDIRECT_URI
    });
    res.redirect(authUrl);
  });

  app.get("/auth/callback", async (req, res) => {
    try {
      const tokenResponse = await msalClient.acquireTokenByCode({
        code: req.query.code,
        scopes: ["User.Read"],
        redirectUri: REDIRECT_URI
      });

      const email = tokenResponse.account.username; // Entra ID's login email
      const identity = await resolveIdentity(email);

      if (!identity) {
        return res.redirect(
          `/index.html?error=${encodeURIComponent("Your account isn't set up yet — ask your manager to add you.")}`
        );
      }

      issueSession(res, identity);
      res.redirect("/dashboard.html");
    } catch (err) {
      console.error("Auth callback failed:", err);
      res.redirect(`/index.html?error=${encodeURIComponent("Sign-in failed. Please try again.")}`);
    }
  });

  // --- Dev-mode stand-in sign-in (only usable while real auth isn't configured) ---
  app.post("/auth/dev-login", async (req, res) => {
    if (isRealAuthConfigured) return res.status(403).json({ error: "Dev sign-in is disabled — real sign-in is configured." });

    const { email } = req.body || {};
    const identity = await resolveIdentity(email);
    if (!identity) return res.status(404).json({ error: "No manager or employee found with that email" });

    issueSession(res, identity);
    res.json({ ok: true });
  });

  app.post("/auth/logout", (req, res) => {
    res.clearCookie(SESSION_COOKIE);
    res.json({ ok: true });
  });

  app.get("/api/me", requireSession, async (req, res) => {
    res.json(req.user);
  });
}
