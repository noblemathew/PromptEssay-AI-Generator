/* ===========================================================
   server.js — Synapse backend.
   =========================================================== */

import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import path from "path";
import { fileURLToPath } from "url";
import { exec } from "child_process";
import { promisify } from "util";

import pool from "./db.js";
import { registerAuthRoutes, requireSession } from "./auth.js";

const execAsync = promisify(exec);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:8000";

app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(express.json());
app.use(cookieParser());

registerAuthRoutes(app);

/* -----------------------------------------------------------
   Access helpers — every route below uses these to figure out
   which manager's data a request is allowed to touch, whether
   the caller is a manager or an employee under one.
   ----------------------------------------------------------- */
function callerManagerId(user) {
  return user.role === "manager" ? user.id : user.m_id;
}

/* ---------------- Projects ---------------- */

app.get("/api/projects", requireSession, async (req, res) => {
  const managerId = callerManagerId(req.user);
  const [rows] = await pool.query(
    `SELECT p.id, p.name,
            (SELECT COUNT(*) FROM project_tools pt WHERE pt.project_id = p.id) AS tool_count
     FROM projects p
     WHERE p.m_id = ?
     ORDER BY p.id DESC`,
    [managerId]
  );
  res.json(rows);
});

app.get("/api/projects/:id", requireSession, async (req, res) => {
  const managerId = callerManagerId(req.user);
  const [rows] = await pool.query(
    "SELECT * FROM projects WHERE id = ? AND m_id = ?",
    [req.params.id, managerId]
  );
  if (rows.length === 0) return res.status(404).json({ error: "Project not found" });
  res.json(rows[0]);
});

app.post("/api/projects", requireSession, async (req, res) => {
  if (req.user.role !== "manager") return res.status(403).json({ error: "Only managers can create projects" });
  const { name } = req.body || {};
  if (!name?.trim()) return res.status(400).json({ error: "Project name is required" });

  const [result] = await pool.query(
    "INSERT INTO projects (name, m_id) VALUES (?, ?)",
    [name.trim(), req.user.id]
  );
  res.status(201).json({ id: result.insertId, name: name.trim() });
});

app.delete("/api/projects/:id", requireSession, async (req, res) => {
  if (req.user.role !== "manager") return res.status(403).json({ error: "Only managers can delete projects" });

  const [rows] = await pool.query(
    "SELECT * FROM projects WHERE id = ? AND m_id = ?",
    [req.params.id, req.user.id]
  );
  if (rows.length === 0) return res.status(404).json({ error: "Project not found" });

  await pool.query("DELETE FROM project_tools WHERE project_id = ?", [req.params.id]);
  await pool.query("DELETE FROM projects WHERE id = ?", [req.params.id]);
  res.status(204).send();
});

/* ---------------- Tools (per project) ---------------- */

app.get("/api/projects/:id/tools", requireSession, async (req, res) => {
  const managerId = callerManagerId(req.user);

  const [owns] = await pool.query("SELECT id FROM projects WHERE id = ? AND m_id = ?", [req.params.id, managerId]);
  if (owns.length === 0) return res.status(404).json({ error: "Project not found" });

  const [tools] = await pool.query(
    `SELECT t.id, t.slug, t.name, t.description
     FROM project_tools pt
     JOIN tools t ON t.id = pt.tool_id
     WHERE pt.project_id = ?
     ORDER BY t.id`,
    [req.params.id]
  );
  res.json(tools);
});

/* ---------------- Employees (team members) ---------------- */

app.get("/api/employees", requireSession, async (req, res) => {
  if (req.user.role !== "manager") return res.status(403).json({ error: "Only managers can view team lists" });
  const [rows] = await pool.query("SELECT id, email, display_name FROM employees WHERE m_id = ? ORDER BY id", [req.user.id]);
  res.json(rows);
});

app.post("/api/employees", requireSession, async (req, res) => {
  if (req.user.role !== "manager") return res.status(403).json({ error: "Only managers can add team members" });
  const { email, display_name } = req.body || {};
  if (!email?.trim()) return res.status(400).json({ error: "Email is required" });

  try {
    const [result] = await pool.query(
      "INSERT INTO employees (email, display_name, m_id) VALUES (?, ?, ?)",
      [email.trim(), display_name || null, req.user.id]
    );
    res.status(201).json({ id: result.insertId, email: email.trim() });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ error: "That email is already added" });
    throw err;
  }
});

app.delete("/api/employees/:id", requireSession, async (req, res) => {
  if (req.user.role !== "manager") return res.status(403).json({ error: "Only managers can remove team members" });

  const [rows] = await pool.query("SELECT * FROM employees WHERE id = ? AND m_id = ?", [req.params.id, req.user.id]);
  if (rows.length === 0) return res.status(404).json({ error: "Team member not found" });

  await pool.query("DELETE FROM employees WHERE id = ?", [req.params.id]);
  res.status(204).send();
});

/* -----------------------------------------------------------
   Webscraper tool proxy — unchanged logic from the original
   Location Discovery Portal build: fetches an Azure AD token
   via the local `az login` session and forwards to the Power
   Automate flow.
   ----------------------------------------------------------- */

const FLOW_URL = process.env.POWER_AUTOMATE_URL;
const TOKEN_RESOURCE = process.env.TOKEN_RESOURCE || "https://service.flow.microsoft.com/";

async function getFlowToken() {
  const { stdout } = await execAsync(`az account get-access-token --resource ${TOKEN_RESOURCE}`);
  const parsed = JSON.parse(stdout);
  if (!parsed.accessToken) throw new Error("No accessToken in az CLI output");
  return parsed.accessToken;
}

app.post("/api/extract", requireSession, async (req, res) => {
  const { company, url } = req.body || {};
  if (!company || !url) return res.status(400).json({ error: "Both 'company' and 'url' are required." });
  if (!FLOW_URL) return res.status(500).json({ error: "Server is missing POWER_AUTOMATE_URL — set it in server/.env" });

  let token;
  try {
    token = await getFlowToken();
  } catch (err) {
    console.error("Token fetch failed:", err.message);
    return res.status(401).json({
      error: "Could not get an Azure AD token. Run `az login` in this server's terminal, then try again.",
      details: err.message
    });
  }

  try {
    const flowRes = await fetch(FLOW_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ company, url })
    });

    const text = await flowRes.text();
    let body;
    try { body = JSON.parse(text); } catch { body = { raw: text }; }

    if (!flowRes.ok) return res.status(502).json({ error: `Flow responded with ${flowRes.status}`, details: body });
    res.json(body);
  } catch (err) {
    console.error(err);
    res.status(502).json({ error: "Could not reach the Power Automate flow", details: String(err) });
  }
});

app.get("/api/health", async (req, res) => {
  let dbOk = false;
  try { await pool.query("SELECT 1"); dbOk = true; } catch { /* leave false */ }
  res.json({ ok: true, dbOk, flowConfigured: Boolean(FLOW_URL) });
});

/* ---------------- Serve the static frontend ---------------- */
app.use(express.static(path.join(__dirname, "..")));

app.listen(PORT, () => {
  console.log(`Synapse backend running at http://localhost:${PORT}`);
});
