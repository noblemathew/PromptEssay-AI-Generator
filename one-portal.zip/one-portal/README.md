# One Portal

A multi-tool internal AI platform: one login, team-scoped projects, and
a growing set of AI tools launched from within each project.

## What's in here

```
one-portal/
├── index.html            Login page (email + password, "Sign in with
│                          Microsoft" is a placeholder for now)
├── dashboard.html          Your projects + your team (managers only)
├── project.html           AI tools enabled for one project
├── tools/
│   ├── webscraper/         Location Discovery tool (fully working)
│   └── coming-soon.html    Placeholder for tools not built yet
├── css/style.css
├── js/
│   ├── config.js            Backend URL
│   └── session.js           Session check + logout, used by every page
└── server/
    ├── server.js            Main Express app — all routes
    ├── auth.js              Email + password login (bcrypt-hashed)
    ├── db.js                SQL Server connection
    ├── schema.sql            Tables + demo seed data (run in SSMS)
    ├── package.json
    └── .env.example
```

## 1. Set up the database in SSMS

Open **SQL Server Management Studio**, connect to your local instance,
click **New Query**, paste the entire contents of `server/schema.sql`,
and click **Execute**. This creates the `one_portal` database, all
tables, and seeds demo data — 1 manager, 2 employees, 4 demo projects,
4 demo AI tools (only "Location Discovery" is wired up so far; the
other 3 show a "coming soon" page).

**Demo login credentials** (also noted at the top of `schema.sql`):
| Email | Password | Role |
|---|---|---|
| andrew@iqvia.com | Welcome123! | Manager |
| teammate1@iqvia.com | TeamPass1! | Employee |
| teammate2@iqvia.com | TeamPass1! | Employee |

Passwords are never stored as plain text — they're hashed with bcrypt
before being written to the database.

## 2. Create a SQL login for the app to connect with

The app connects with a SQL Server login, not Windows Authentication
(more reliable from Node). In the same SSMS query window:
```sql
CREATE LOGIN portal_app WITH PASSWORD = 'YourStrongPassword123!', CHECK_POLICY = OFF;
USE one_portal;
CREATE USER portal_app FOR LOGIN portal_app;
ALTER ROLE db_owner ADD MEMBER portal_app;
```
Also confirm your SQL Server instance allows SQL logins (not just
Windows accounts): right-click the server in SSMS → **Properties** →
**Security** → select **"SQL Server and Windows Authentication mode"**
→ restart the SQL Server service if you had to change this.

## 3. Configure and run the backend

```
cd server
npm install
cp .env.example .env
```
Fill in `.env`:
- `DB_SERVER` — usually `localhost`, or `localhost\SQLEXPRESS` if
  that's what SSMS shows as your server name.
- `DB_USER` / `DB_PASSWORD` — the `portal_app` login from step 2.
- `SESSION_SECRET` — any long random string.

```
npm start
```

Open **http://localhost:3000** — one server serves both the frontend
and the API.

## About "Sign in with Microsoft"

The button is on the login page, but it's a placeholder for now — it
shows a message rather than actually signing anyone in. Real Microsoft
sign-in needs an Entra ID app registration, which requires Azure admin
access this project doesn't have yet. During a demo, you can explain:
*"this connects once IT sets up Azure — for now, sign in with email
and password below."* Everything else about the app works exactly the
same either way.

## Adding a new manager

No UI for this yet — generate a bcrypt hash for their password and
insert directly in SSMS:
```
node -e "import('bcryptjs').then(async b => console.log(await b.hash('TheirPassword123!', 10)))"
```
```sql
INSERT INTO managers (email, display_name, password_hash)
VALUES ('newmanager@iqvia.com', 'Their Name', '<hash from above>');
```

## Adding more AI tools later

1. Add a row to the `tools` table (slug, name, description).
2. Enable it for whichever projects should have it, in `project_tools`.
3. Build the tool's pages under `tools/<slug>/`, following the pattern
   in `tools/webscraper/` (include `js/session.js` for the login guard).
4. In `project.html`'s `TOOL_ICONS`/`TOOL_COLORS` objects, add an entry
   for the new slug, and add a case in the click handler to navigate
   to the new tool instead of falling into "coming soon."

## Security notes

- Passwords are bcrypt-hashed (10 rounds) — never stored or logged in
  plain text.
- Sessions are signed JWTs in an httpOnly cookie — set `secure: true`
  in `auth.js` once this is served over HTTPS.
- Login errors are intentionally generic ("incorrect email or
  password") whether the email exists or not.
- New employees are given a temporary password (`ChangeMe123!`),
  shown once to the manager when adding them — there's no self-service
  "set your own password" flow yet, worth adding before wider rollout.
