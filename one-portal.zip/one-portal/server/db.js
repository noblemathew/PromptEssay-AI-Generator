/* ===========================================================
   db.js — SQL Server connection, using the same login pattern
   that already worked in SSMS/testing earlier (SQL login, not
   Windows auth, so Node can connect the same way every time).

   Exposes a small `query(text, params)` helper so the rest of
   the app can write SQL Server-style @param queries without
   dealing with the mssql library's request/input API directly.
   =========================================================== */

import sql from "mssql";
import "dotenv/config";

const config = {
  server: process.env.DB_SERVER || "localhost",
  database: process.env.DB_NAME || "one_portal",
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    trustServerCertificate: true
  }
};

const poolPromise = sql.connect(config);

poolPromise
  .then(() => console.log("Connected to SQL Server"))
  .catch(err => console.error("SQL Server connection failed:", err.message));

/**
 * Run a parameterized query.
 *   await query("SELECT * FROM managers WHERE email = @email", { email });
 * Returns the result rows as a plain array (like mysql2's style),
 * so route code doesn't need to know about mssql's recordset shape.
 */
export async function query(text, params = {}) {
  const pool = await poolPromise;
  const request = pool.request();
  for (const [key, value] of Object.entries(params)) {
    request.input(key, value);
  }
  const result = await request.query(text);
  return result.recordset;
}

export { sql };
