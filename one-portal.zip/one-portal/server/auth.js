/* ===========================================================
   auth.js — email + password sign-in, checked against bcrypt
   password hashes stored in the managers/employees tables.
   Session is a signed JWT in an httpOnly cookie.

   The "Sign in with Microsoft" button on the login page is a
   placeholder for now — wire it up to real Entra ID once an
   app registration is available (see README).
   =========================================================== */

import "dotenv/config";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { query } from "./db.js";

const SESSION_SECRET = process.env.SESSION_SECRET || "dev-secret-change-me";
const SESSION_COOKIE = "portal_session";

function issueSession(res, identity) {
  const token = jwt.sign(identity, SESSION_SECRET, { expiresIn: "8h" });
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: false, // set true once served over HTTPS
    maxAge: 8 * 60 * 60 * 1000
  });
}

export function requireSession(req, res, next) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return res.status(401).json({ error: "Not signed in" });
  try {
    req.user = jwt.verify(token, SESSION_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Session expired — please sign in again" });
  }
}

export function registerAuthRoutes(app) {
  app.post("/auth/login", async (req, res) => {
    const { email, password } = req.body || {};
    if (!email?.trim() || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const managers = await query("SELECT * FROM managers WHERE email = @email", { email: email.trim() });
    if (managers.length > 0) {
      const ok = await bcrypt.compare(password, managers[0].password_hash);
      if (!ok) return res.status(401).json({ error: "Incorrect email or password" });
      const identity = { role: "manager", id: managers[0].id, email: managers[0].email, display_name: managers[0].display_name };
      issueSession(res, identity);
      return res.json(identity);
    }

    const employees = await query("SELECT * FROM employees WHERE email = @email", { email: email.trim() });
    if (employees.length > 0) {
      const ok = await bcrypt.compare(password, employees[0].password_hash);
      if (!ok) return res.status(401).json({ error: "Incorrect email or password" });
      const identity = { role: "employee", id: employees[0].id, m_id: employees[0].m_id, email: employees[0].email, display_name: employees[0].display_name };
      issueSession(res, identity);
      return res.json(identity);
    }

    res.status(401).json({ error: "Incorrect email or password" });
  });

  app.post("/auth/logout", (req, res) => {
    res.clearCookie(SESSION_COOKIE);
    res.json({ ok: true });
  });

  app.get("/api/me", requireSession, async (req, res) => {
    res.json(req.user);
  });
}
