-- ===========================================================
-- One Portal — SQL Server schema
-- Run this in SSMS: open a New Query window against your
-- SQL Server instance, paste this whole script, and click Execute.
-- ===========================================================

CREATE DATABASE one_portal;
GO

USE one_portal;
GO

CREATE TABLE managers (
  id            INT IDENTITY(1,1) PRIMARY KEY,
  email         NVARCHAR(255) UNIQUE NOT NULL,
  display_name  NVARCHAR(255),
  password_hash NVARCHAR(255) NOT NULL
);

CREATE TABLE employees (
  id            INT IDENTITY(1,1) PRIMARY KEY,
  email         NVARCHAR(255) UNIQUE NOT NULL,
  display_name  NVARCHAR(255),
  password_hash NVARCHAR(255) NOT NULL,
  m_id          INT FOREIGN KEY REFERENCES managers(id)
);

CREATE TABLE projects (
  id     INT IDENTITY(1,1) PRIMARY KEY,
  name   NVARCHAR(255) NOT NULL,
  m_id   INT FOREIGN KEY REFERENCES managers(id)
);

CREATE TABLE tools (
  id          INT IDENTITY(1,1) PRIMARY KEY,
  slug        NVARCHAR(100) UNIQUE NOT NULL,
  name        NVARCHAR(255) NOT NULL,
  description NVARCHAR(500)
);

CREATE TABLE project_tools (
  project_id INT FOREIGN KEY REFERENCES projects(id),
  tool_id    INT FOREIGN KEY REFERENCES tools(id),
  PRIMARY KEY (project_id, tool_id)
);
GO

-- ---------------- Seed data (edit freely) ----------------
-- Demo login credentials (for testing the password login form):
--   andrew@iqvia.com     / Welcome123!
--   teammate1@iqvia.com  / TeamPass1!
--   teammate2@iqvia.com  / TeamPass1!
-- Passwords are stored as bcrypt hashes below — never store plain text.

INSERT INTO managers (email, display_name, password_hash) VALUES
  ('andrew@iqvia.com', 'Andrew', '$2b$10$/j7mRUe2T7uaWoECIyVML.gdPY5nhPSH8/Mdr6ZZGbokxD95YR4ky');

INSERT INTO employees (email, display_name, password_hash, m_id) VALUES
  ('teammate1@iqvia.com', 'Priya Nair',  '$2b$10$mG2TBqsuUDeUNSnFSaRhIOM0COx3Sg3xwg6/A2haztLnN1f5Z1G4C', 1),
  ('teammate2@iqvia.com', 'Daniel Osei', '$2b$10$mG2TBqsuUDeUNSnFSaRhIOM0COx3Sg3xwg6/A2haztLnN1f5Z1G4C', 1);

INSERT INTO tools (slug, name, description) VALUES
  ('webscraper',      'Location Discovery',      'Extracts business locations from a company website'),
  ('task-planner',    'Task Assignment Agent',   'Plans, prioritizes and assigns tasks by team member skill'),
  ('doc-summarizer',  'Document Summarizer',     'Summarizes long documents into key points'),
  ('meeting-notes',   'Meeting Notes Analyzer',  'Extracts action items and decisions from meeting transcripts');

INSERT INTO projects (name, m_id) VALUES
  ('Navista Location Mapping',    1),
  ('Q3 Task Planning',            1),
  ('Client Onboarding Analysis',  1),
  ('Regional Outreach Review',    1);

-- Which tools are enabled on which demo project
INSERT INTO project_tools (project_id, tool_id) VALUES
  (1, 1), (1, 2), (1, 3), (1, 4),   -- Navista Location Mapping: all 4
  (2, 2), (2, 3),                    -- Q3 Task Planning
  (3, 1), (3, 4),                    -- Client Onboarding Analysis
  (4, 2), (4, 3), (4, 4);            -- Regional Outreach Review
