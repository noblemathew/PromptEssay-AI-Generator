# Location Discovery (Webscraper) Tool — recovered files

These are the 4 pages for the Location Discovery tool, plus the shared
css/js they depend on, recovered from your One Portal project.

## Where these go
This tool is meant to live *inside* your existing `one-portal` project,
not run standalone. Copy things back like this:

```
one-portal/
├── css/style.css        <- overwrite with the css/style.css from this zip
├── js/config.js          <- overwrite with the js/config.js from this zip
├── js/session.js         <- overwrite with the js/session.js from this zip
└── tools/webscraper/     <- overwrite with the tools/webscraper/*.html from this zip
    ├── home.html
    ├── results.html
    ├── workflow.html
    └── agent.html
```

## Why it won't work if you just open these files on their own
- `js/session.js` calls your backend (`/api/me`, `/auth/logout`) to check
  you're logged in — that only works when the One Portal backend
  (`server/server.js`) is running.
- The "Back to project" link points to `../../project.html`, which only
  exists inside the full `one-portal` app.
- `home.html`'s "Extract Locations" button calls `/api/extract`, which
  is a route on your backend, not something these static files can do
  alone.

So: drop these back into your existing `one-portal` folder structure
exactly as shown above, and run it the same way as before
(`npm start` in `server/`, then open `http://localhost:3000`).

## What's included in this recovery
- The 4 working pages: Home (pick a site + extract), Results (parses
  the flow's response into a table, with CSV export), Workflow (pipeline
  diagram), Agent Control (manual trigger + console).
- "Agent Control" has been removed from the sidebar navigation on all
  4 pages per your last request — the page itself still exists at
  `agent.html` if you want to link to it again later, just not shown
  in the nav menu currently.
- Each page has a "Back to project" link at the top of the sidebar,
  which returns to that project's tool tiles (`project.html?id=...`).
